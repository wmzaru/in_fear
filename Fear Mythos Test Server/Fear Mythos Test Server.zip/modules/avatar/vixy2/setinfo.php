<?php
$setindex = 2;
$setname = "Set 2";
$setcopy = "&copy; 2004-2005 <a href='http://www.michelledockrey.com'>Michelle Dockrey</a>"
?>
