<?php
	output("Create a new dwelling:`n");
	require_once("modules/dwellingseditor/lib.php");
	dwellingform(array());
?>