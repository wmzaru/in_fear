<?php
// translator ready
// addnews ready
// mail ready
header("Location: home.php?".$_SERVER['QUERY_STRING']);
?>