<?php
//This file automatically created by installer.php on Jan 20, 2013 10:39 am
$DB_HOST = 'localhost';
$DB_USER = 'LotGD';
$DB_PASS = 'CjBaKvEW2NwXbGrY';
$DB_NAME = 'LotGD';
$DB_PREFIX = '';
$DB_USEDATACACHE = 1;
$DB_DATACACHEPATH = 'D:\\wamp\\www\\cache';
?>
