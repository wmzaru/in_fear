<?php
output("`#By continuing with this installation, you indicate your agreement with the terms of the license found on the previous page (License Agreement).");
?>